<?php

  $a = 1;
  $b = 2;
  
  $a = $b + $a; // $a = 3
  $b = $a - $b; //$b = 1
  $a = $a - $b //$a = 2
  
  echo $a;
  echo $b;
  
  ?>