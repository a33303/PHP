<?php

define('ROOT_DIR', __DIR__ . '/../');
define('PUBLIC_DIR', ROOT_DIR . 'public/');
define('ENGINE_DIR', ROOT_DIR . 'engine/');
define('IMG_DIR', PUBLIC_DIR . 'img/');
define('VIEWS_DIR', ROOT_DIR . 'views/');

?>